import UIKit

class Ajedrez
{
    var reinas = [Reina]()
    var noMovs: Int
    
    init(noMovs: Int)
    {
        self.noMovs = noMovs
    }
    
    struct Reina {
        var fil: Int
        var col: Int
    }
    
    func Ubi (coordenada fil: Int, col: Int) -> Bool
    {
        for reina in reinas
        {
            if reina.fil == fil { return false }
            if reina.col == col { return false }
            if abs(reina.fil-fil) == abs(reina.col-col) { return false }
        }
        return true
    }
    func Jugar()
    {
        Busqueda(coordenada: 0)
    }
    
    func Busqueda(coordenada fil: Int)
    {
        if reinas.count < noMovs
        {
            for col in 0...noMovs-1
            {
                if Ubi(coordenada: fil, col: col)
                {
                    let reina = Reina(fil: fil, col: col)
                    reinas.append(reina)
                    Busqueda(coordenada: fil)
                    if reinas.count == noMovs
                    {
                        print(Resultado())
                    }
                    reinas.removeLast()
                }
            }
        }
    }
    
    func Resultado() -> String {
        var blanco = ""
        for lugar in reinas {
            blanco += "(\(lugar.fil),\(lugar.col))"
        }
        return blanco
    }
}

let tablero = Ajedrez(noMovs: 4)
tablero.Jugar()
